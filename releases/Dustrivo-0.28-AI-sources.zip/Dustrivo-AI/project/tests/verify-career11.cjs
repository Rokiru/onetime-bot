const {chromium}=require('./browser-tools.cjs');
const path=require('path'),assert=require('assert'),input=require('./driving-input11.cjs');
(async()=>{const b=await chromium.launch({executablePath:process.env.CARGO_CHROME||require('./browser-tools.cjs').executablePath,args:['--no-sandbox']});
try{const p=await b.newPage({viewport:{width:850,height:393}}),errors=[];p.on('pageerror',e=>errors.push(e.message));await p.addInitScript('window.testDriveInput='+input.toString());await p.goto('file://'+path.resolve('game/assets/index.html'));await p.click('#boot-skip');await p.waitForTimeout(550);
await p.evaluate(()=>{switchProfile('career');save.sound=false;save.music=false;save.motion=false;save.dialogues=false;save.tutorialDone=true;persist();applySettings();});assert.equal(await p.evaluate(()=>save.wallet),0);
const sequence=await p.evaluate(()=>STORY.sequence);let income=0;
for(let at=0;at<sequence.length;at++){
 const id=sequence[at];assert.equal(await p.evaluate(id=>routeUnlocked(id),id),true);if(at+1<sequence.length)assert.equal(await p.evaluate(id=>routeUnlocked(id),sequence[at+1]),false);
 if(at===18){await p.click('#garage-open');await p.click('[data-vehicle="timber"]');await p.click('#vehicle-confirm');for(let category=0;category<3;category++)await p.click('[data-buy="'+category+'"]');await p.click('#garage-close');assert.equal(await p.evaluate(()=>save.owned.includes('timber')),true);}if(at===6){await p.click('#garage-open');for(let step=0;step<2;step++)for(let category=0;category<3;category++)await p.click('[data-buy="'+category+'"]');await p.click('#garage-close');assert.deepEqual(await p.evaluate(()=>save.levels),[2,2,2]);}
 const result=await p.evaluate(id=>{selected=id;save.selected=id;beginDrive();const s=sim;for(let n=0;n<30000&&s.state==='drive';n++)s.step(...testDriveInput(s,CargoPhysics));if(s.state!=='win')return {ok:false,reason:s.reason,x:s.car.getPosition().x};finish();const wallet=save.wallet,payout=s.payout;finish();return {ok:true,wallet,payout,double:save.wallet!==wallet,state:mode};},id);
 assert(result.ok,'career delivery '+id+' '+JSON.stringify(result));assert.equal(result.double,false);assert.equal(result.state,'result');income+=result.payout;assert.equal(await p.evaluate(id=>save.stats[id].wins,id),1);await p.click('#result-home');
 console.log('DELIVERED',at+1,id,'wallet',result.wallet);
}
assert.equal(await p.evaluate(()=>completedJobs()),24);assert((await p.locator('#career-title').textContent()).includes('ВСЕ ДОРОГИ'));assert.equal(await p.evaluate(()=>save.deliveries),24);assert.equal(await p.evaluate(()=>save.earned),income);
const state=await p.evaluate(()=>({wallet:save.wallet,earned:save.earned,stats:save.stats,levels:save.levels}));await p.reload();await p.click('#boot-skip');await p.waitForTimeout(550);assert.deepEqual(await p.evaluate(()=>({wallet:save.wallet,earned:save.earned,stats:save.stats,levels:save.levels})),state);
await p.evaluate(()=>openVillage());assert((await p.locator('#village-next').textContent()).includes('Свет вернулся'));await p.click('#village-close');
// Radio preference persists independently from dispatch story briefs.
await p.click('#settings-open');await p.click('#radio-toggle');await p.click('#settings-done');assert.equal(await p.evaluate(()=>save.radio),false);await p.reload();await p.click('#boot-skip');await p.waitForTimeout(550);assert.equal(await p.evaluate(()=>save.radio),false);
await p.evaluate(()=>{save.dialogues=true;selected=0;save.briefed[0]=false;start();});assert(await p.locator('#briefing').isVisible());await p.click('#briefing-drive');assert.equal(await p.evaluate(()=>CargoGame.mode),'drive');await p.evaluate(()=>{sayDriver('Тестовая реплика','focus',true);});assert(await p.locator('#driver-radio').isHidden());
assert.deepEqual(errors,[]);console.log('PASS career: 24 actual deliveries; sequential unlocks; purchased intermediate upgrades; payments once; earned total; reload; preserved village; independent radio preference');
}finally{await b.close();}})();
