const assert=require('assert'),P=require('../game/assets/physics.js');
let held=[];for(let id=0;id<3;id++)for(const m of P.vehicles){const s=new P.Drive(id,[0,0,0],m.id);for(let n=0;n<18000&&s.state==='drive';n++)s.step(true,false);held.push({id,car:m.id,state:s.state,reason:s.reason});assert.equal(s.state,'fail','held gas must lose '+id+' '+m.id);}
const s=new P.Drive(0,[0,0,0]);s.step(false,true);assert.equal(s.joints[0].getMotorSpeed(),0,'brake is not immediate reverse');for(let n=0;n<60;n++)s.step(false,true);assert(s.car.getLinearVelocity().x<0,'hold brake engages reverse');
const stopped=new P.Drive(0,[0,0,0]);for(let n=0;n<120;n++)stopped.step(true,true);assert(Math.abs(stopped.car.getLinearVelocity().x)<.1,'both pedals hold still');
assert.equal(P.routes.length,28);assert.equal(P.regions.length,6);assert.equal(new Set(P.routes.map((r,id)=>JSON.stringify(P.profiles[id]))).size,28);
for(let id=0;id<24;id++){const a=P.groundVertices(id),b=P.groundVertices(id);assert.strictEqual(a,b,'cached world mesh');assert.equal(a[0].x,-30);for(let i=1;i<a.length;i++){assert.equal(a[i].x-a[i-1].x,.5);assert.equal(a[i].y,P.groundHeight(a[i].x,id));}}
for(const [id,g] of Object.entries(P.gaps))assert(P.groundHeight((g.from+g.to)/2,+id)<g.y-3,'real ravine '+id);
for(const m of P.vehicles){const drop=new P.Drive(3,[0,0,0],m.id);for(const b of [drop.car,...drop.wheels,...drop.boxes.map(x=>x.body)]){const p=b.getPosition();b.setPosition({x:p.x,y:p.y+2});}for(let n=0;n<600;n++){drop.suspensionForces();drop.world.step(1/120,6,3);}assert(Math.abs(drop.car.getLinearVelocity().y)<.25,'suspension settles '+m.id);}
console.log('PASS mechanics: held-gas failures',held,'; progressive reverse, both pedals, 28 distinct roads, stable shared mesh, real ravines, 3 suspension drops');
